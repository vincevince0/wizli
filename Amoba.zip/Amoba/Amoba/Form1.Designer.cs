﻿namespace Amoba
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            gameArea = new Panel();
            widthSet = new NumericUpDown();
            heightSet = new NumericUpDown();
            requiredSet = new NumericUpDown();
            start = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            nextPlayer = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            label5 = new Label();
            textBox2 = new TextBox();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)widthSet).BeginInit();
            ((System.ComponentModel.ISupportInitialize)heightSet).BeginInit();
            ((System.ComponentModel.ISupportInitialize)requiredSet).BeginInit();
            SuspendLayout();
            // 
            // gameArea
            // 
            gameArea.BackColor = SystemColors.ActiveCaption;
            gameArea.BorderStyle = BorderStyle.FixedSingle;
            gameArea.Location = new Point(12, 54);
            gameArea.Name = "gameArea";
            gameArea.Size = new Size(400, 400);
            gameArea.TabIndex = 0;
            // 
            // widthSet
            // 
            widthSet.Location = new Point(12, 25);
            widthSet.Name = "widthSet";
            widthSet.Size = new Size(96, 23);
            widthSet.TabIndex = 1;
            widthSet.Value = new decimal(new int[] { 3, 0, 0, 0 });
            // 
            // heightSet
            // 
            heightSet.Location = new Point(112, 25);
            heightSet.Name = "heightSet";
            heightSet.Size = new Size(96, 23);
            heightSet.TabIndex = 2;
            heightSet.Value = new decimal(new int[] { 3, 0, 0, 0 });
            // 
            // requiredSet
            // 
            requiredSet.Location = new Point(212, 25);
            requiredSet.Name = "requiredSet";
            requiredSet.Size = new Size(96, 23);
            requiredSet.TabIndex = 3;
            requiredSet.Value = new decimal(new int[] { 3, 0, 0, 0 });
            // 
            // start
            // 
            start.Location = new Point(312, 25);
            start.Name = "start";
            start.Size = new Size(98, 23);
            start.TabIndex = 4;
            start.Text = "Start";
            start.UseVisualStyleBackColor = true;
            start.Click += Start;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 7);
            label1.Name = "label1";
            label1.Size = new Size(27, 15);
            label1.TabIndex = 5;
            label1.Text = "Sor:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(112, 7);
            label2.Name = "label2";
            label2.Size = new Size(46, 15);
            label2.TabIndex = 6;
            label2.Text = "Oszlop:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(212, 7);
            label3.Name = "label3";
            label3.Size = new Size(85, 15);
            label3.TabIndex = 7;
            label3.Text = "Nyeréshez kell:";
            // 
            // nextPlayer
            // 
            nextPlayer.AutoSize = true;
            nextPlayer.Location = new Point(312, 7);
            nextPlayer.Name = "nextPlayer";
            nextPlayer.Size = new Size(45, 15);
            nextPlayer.TabIndex = 8;
            nextPlayer.Text = "Kezd: X";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 457);
            label4.Name = "label4";
            label4.Size = new Size(57, 15);
            label4.TabIndex = 9;
            label4.Text = "X pontjai:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(14, 476);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(55, 23);
            textBox1.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(75, 457);
            label5.Name = "label5";
            label5.Size = new Size(59, 15);
            label5.TabIndex = 11;
            label5.Text = "O pontjai:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(77, 476);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(55, 23);
            textBox2.TabIndex = 12;
            // 
            // button1
            // 
            button1.Location = new Point(312, 472);
            button1.Name = "button1";
            button1.Size = new Size(98, 23);
            button1.TabIndex = 13;
            button1.Text = "Új játék";
            button1.UseVisualStyleBackColor = true;
            button1.Click += NewGameButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(427, 507);
            Controls.Add(button1);
            Controls.Add(textBox2);
            Controls.Add(label5);
            Controls.Add(textBox1);
            Controls.Add(label4);
            Controls.Add(nextPlayer);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(start);
            Controls.Add(requiredSet);
            Controls.Add(heightSet);
            Controls.Add(widthSet);
            Controls.Add(gameArea);
            Name = "Form1";
            Text = "Amőba";
            ((System.ComponentModel.ISupportInitialize)widthSet).EndInit();
            ((System.ComponentModel.ISupportInitialize)heightSet).EndInit();
            ((System.ComponentModel.ISupportInitialize)requiredSet).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel gameArea;
        private NumericUpDown widthSet;
        private NumericUpDown heightSet;
        private NumericUpDown requiredSet;
        private Button start;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label nextPlayer;
        private Label label4;
        private TextBox textBox1;
        private Label label5;
        private TextBox textBox2;
        private Button button1;
    }
}