namespace Amoba
{
    public partial class Form1 : Form
    {
        int width, height;
        Button[,] fields;
        char[,] takenBy;
        int steps;
        int required;
        int xpont, opont;

        public Form1()
        {
            InitializeComponent();
        }

        public void SetFields()
        {

            fields = new Button[Width, Height];
            takenBy = new char[Width, Height];
            steps = 0;

            for (int i = 0; i < Width; i++)
            {
                for (int j = 0; j < Height; j++)
                {
                    fields[i, j] = new Button();
                    fields[i, j].Name = $"{i}:{j}";
                    fields[i, j].Width = gameArea.Width / Width;
                    fields[i, j].Height = gameArea.Height / Height;
                    fields[i, j].Location = new Point((gameArea.Width / Width) * i, (gameArea.Height / Height) * j);
                    fields[i, j].Click += PlayerStep;
                    fields[i, j].Click += CheckWinner;
                    fields[i, j].BackgroundImageLayout = ImageLayout.Stretch;

                    gameArea.Controls.Add(fields[i, j]);

                    takenBy[i, j] = ' ';

                }
            }
        }
        private void NewGameButton_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < Width; i++)
            {
                for (int j = 0; j < Height; j++)
                {
                    takenBy[i, j] = ' ';
                    fields[i, j].BackgroundImage = null; 
                }
            }

            steps = 0;
            nextPlayer.Text = "K�vetkezik: X"; 
        }

        public void CheckWinner(object sender, EventArgs e)
        {
            //oszlop
            for (int i = 0; i < Width; i++)
            {
                int col = 1;
                for (int j = 1; j < Height; j++)
                {
                    if (takenBy[i, j] != ' ' && takenBy[i, j - 1] == takenBy[i, j])
                    {
                        col++;
                    }
                    else
                    {
                        col = 1;
                    }

                    if (col >= required)
                    {
                        MessageBox.Show("Nyert: " + takenBy[i, j]);
                        if (takenBy[i,j] == 'X')
                        {
                            xpont++;
                        }
                        else
                        {
                            opont++;
                        }
                        textBox1.Text = ""+xpont;
                        textBox2.Text = ""+opont;
                        return;
                    }
                }
            }

            //sor
            for (int i = 0; i < Height; i++)
            {
                int row = 1;
                for (int j = 1; j < Width; j++)
                {
                    if (takenBy[j, i] != ' ' && takenBy[j - 1, i] == takenBy[j, i])
                    {
                        row++;
                    }
                    else
                    {
                        row = 1;
                    }

                    if (row >= required)
                    {
                        MessageBox.Show("Nyert: " + takenBy[j, i]);
                        if (takenBy[j, i] == 'X')
                        {
                            xpont++;
                        }
                        else
                        {
                            opont++;
                        }
                        textBox1.Text = "" + xpont;
                        textBox2.Text = "" + opont;
                        return;
                    }
                }
            }

            //�tl�k
            for (int i = 0; i <= Width - required; i++) 
            {
                for (int j = 0; j <= Height - required; j++)
                {
                    int diag = 1;
                    for (int k = 1; k < required; k++) 
                    {
                        if (takenBy[i + k, j + k] == takenBy[i, j] && takenBy[i, j] != ' ')
                        {
                            diag++;
                        }
                        else
                        {
                            break;
                        }
                    }
                    if (diag >= required)
                    {
                        MessageBox.Show("Nyert: " + takenBy[i, j]);
                        if (takenBy[i, j] == 'X')
                        {
                            xpont++;
                        }
                        else
                        {
                            opont++;
                        }
                        textBox1.Text = "" + xpont;
                        textBox2.Text = "" + opont;
                        return;
                    }
                }
            }

            
            for (int i = 0; i <= Width - required; i++) 
            {
                for (int j = required - 1; j < Height; j++) 
                {
                    int diag = 1; 
                    for (int k = 1; k < required; k++) 
                    {
                        if (takenBy[i + k, j - k] == takenBy[i, j] && takenBy[i, j] != ' ')
                        {
                            diag++;
                        }
                        else
                        {
                            break;
                        }
                    }
                    if (diag >= required)
                    {
                        MessageBox.Show("Nyert: " + takenBy[i, j]);
                        if (takenBy[i, j] == 'X')
                        {
                            xpont++;
                        }
                        else
                        {
                            opont++;
                        }
                        textBox1.Text = "" + xpont;
                        textBox2.Text = "" + opont;
                        return;
                    }
                }

            }
            }

        public void PlayerStep(object sender, EventArgs e)
        {
            Button clicked = (Button)sender;

            
            if (clicked.BackgroundImage != null) return;

            int[] coords = Array.ConvertAll(clicked.Name.Split(":"), Convert.ToInt32);
            int x = coords[0], y = coords[1];

            if (steps % 2 == 0)
            {
                takenBy[x, y] = 'X';
                clicked.BackgroundImage = Image.FromFile("x.png");
                nextPlayer.Text = "K�vetkezik: O";
            }
            else
            {
                takenBy[x, y] = 'O';
                clicked.BackgroundImage = Image.FromFile("o.png");
                nextPlayer.Text = "K�vetkezik: X";
            }

            steps++;

        }
        public int Width
        {
            get { return width; }
            set
            {
                if(value>=3 && value<=12)
                {
                    width = value;
                }
                else
                { 
                    throw new Exception($"A sz�less�g csak 3 �s 12 k�z�tt lehet\nRossz adat: {value}");
                }
            }
        }
        public int Height
        {
            get { return height; }
            set
            {
                if (value >= 3 && value <= 12)
                {
                    height = value;
                }
                else
                {
                    throw new Exception($"A magass�g csak 3 �s 12 k�z�tt lehet\nRossz adat: {value}");
                }
            }
        }
        private void Start(object sender, EventArgs e)
        {
            
            Width = (int)widthSet.Value;
            Height = (int)heightSet.Value;
            required = (int)requiredSet.Value;        
            SetFields();


        }
    }
}